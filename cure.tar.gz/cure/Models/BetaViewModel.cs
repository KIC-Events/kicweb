﻿namespace Cure.Models
{
    public class BetaViewModel
    {
        public string BetaCode { get; set; }
    }
}
